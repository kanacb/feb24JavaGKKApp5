import('./bootstrap').catch(err => console.error(err));
