/**
 * Service layer.
 */
package com.mycompany.myapp.service;
